const meal_plans = [
    {
        "id": 1,
        "name": "e/p"
    },
    {
        "id": 2,
        "name": "b/b"
    },
    {
        "id": 3,
        "name": "h/b"
    },
    {
        "id": 4,
        "name": "f/b"
    },
    {
        "id": 5,
        "name": "inc"
    }
];
export default meal_plans;