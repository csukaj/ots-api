const islands = [
    {
        "id": 1,
        "priority": 0,
        "name": "Mahé",
        "districts": [
            {
                "id": 1,
                "name": "Anse aux Pins"
            },
            {
                "id": 2,
                "name": "Anse Boileau"
            },
            {
                "id": 3,
                "name": "Anse Etoile"
            },
            {
                "id": 4,
                "name": "Au Cap"
            },
            {
                "id": 5,
                "name": "Anse Royale"
            },
            {
                "id": 6,
                "name": "Baie Lazare"
            },
            {
                "id": 7,
                "name": "Beau Vallon"
            },
            {
                "id": 8,
                "name": "Bel Air"
            },
            {
                "id": 9,
                "name": "Bel Ombre"
            },
            {
                "id": 10,
                "name": "Cascade"
            },
            {
                "id": 11,
                "name": "Glacis"
            },
            {
                "id": 12,
                "name": "Grand'Anse"
            },
            {
                "id": 13,
                "name": "English River"
            },
            {
                "id": 14,
                "name": "Mont Buxton"
            },
            {
                "id": 15,
                "name": "Mont Fleuri"
            },
            {
                "id": 16,
                "name": "Plaisance"
            },
            {
                "id": 17,
                "name": "Pointe La Rue"
            },
            {
                "id": 18,
                "name": "Port Glaud"
            },
            {
                "id": 19,
                "name": "Saint Louis"
            },
            {
                "id": 20,
                "name": "Takamaka"
            },
            {
                "id": 21,
                "name": "Les Mamelles"
            },
            {
                "id": 22,
                "name": "Roche Caïman"
            }
        ]
    },
    {
        "id": 3,
        "priority": 1,
        "name": "Praslin",
        "districts": [
            {
                "id": 24,
                "name": "Baie Sainte Anne"
            },
            {
                "id": 25,
                "name": "Grand'Anse Praslin"
            }
        ]
    },
    {
        "id": 2,
        "priority": 2,
        "name": "La Digue",
        "districts": [
            {
                "id": 23,
                "name": "La Digue and Inner Islands"
            }
        ]
    },
    {
        "id": 4,
        "priority": 3,
        "name": "Cerf",
        "districts": [
            {
                "id": 26,
                "name": "Mont Fleuri"
            }
        ]
    },
    {
        "id": 5,
        "priority": 4,
        "name": "St. Anne",
        "districts": [
            {
                "id": 27,
                "name": "Mont Fleuri"
            }
        ]
    }
];
export default islands;